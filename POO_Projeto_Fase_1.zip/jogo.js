class Sala {
    constructor(nome, descricao) {
        this.nome = nome;
        this.descricao = descricao;
        this.passagens = [];
        this.objetos = [];
    }

    adicionarPassagem(sala) {
        this.passagens.push(sala);
    }

    adicionarObjeto(objeto) {
        this.objetos.push(objeto);
    }

    descreverSala() {
        console.log(`Você está na sala: ${this.nome}`);
        console.log(`${this.descricao}`);
        console.log('Passagens disponíveis:');
        this.passagens.forEach(sala => console.log(`- Para a sala: ${sala.nome}`));
        console.log('Objetos na sala:');
        this.objetos.forEach(objeto => console.log(`- ${objeto.nome}: ${objeto.descricao}`));
    }
}

class Objeto {
    constructor(nome, descricao, utilizavel = false) {
        this.nome = nome;
        this.descricao = descricao;
        this.utilizavel = utilizavel;  // Se o objeto pode ser usado com uma ferramenta
    }

    usar(objeto) {
        if (this.utilizavel) {
            console.log(`Você usou o ${this.nome} no ${objeto.nome}.`);
        } else {
            console.log(`${this.nome} não pode ser usado.`);
        }
    }
}

class Ferramenta extends Objeto {
    constructor(nome, descricao, durabilidade) {
        super(nome, descricao, true);
        this.durabilidade = durabilidade;
    }

    usar(objeto) {
        if (this.durabilidade > 0) {
            super.usar(objeto);
            this.durabilidade;
            console.log(`Durabilidade restante: ${this.durabilidade}`);
        } else {
            console.log(`A ferramenta ${this.nome} está sem durabilidade.`);
        }
    }
}

class Jogador {
    constructor(nome) {
        this.nome = nome;
        this.salaAtual = null;
        this.mochila = [];
    }

    entrarNaSala(sala) {
        this.salaAtual = sala;
        sala.descreverSala();
    }

    pegarObjeto(objeto) {
        if (this.mochila.length < 1) {  // O jogador pode carregar no máximo uma ferramenta
            this.mochila.push(objeto);
            console.log(`${objeto.nome} foi adicionado à mochila.`);
        } else {
            console.log('Você já está carregando uma ferramenta.');
        }
    }
    esvaziarMochila() {
        this.mochila.pop()
        console.log("Mochila esvaziada.")
    }

    usarFerramenta(objeto) {
        if (this.mochila.length > 0) {
            let ferramenta = this.mochila[0];  // Só tem uma ferramenta na mochila
            ferramenta.usar(objeto);
        } else {
            console.log('Você não tem nenhuma ferramenta na mochila.');
        }
    }

    sairDaSala(sala) {
        if (this.salaAtual.passagens.includes(sala)) {
            this.entrarNaSala(sala);
        } else {
            console.log('Não há passagem para essa sala.');
        }
    }
}

// Criando as salas
const salaEntrada = new Sala('Sala de Entrada', 'Você está na sala de entrada da mansão. Há passagens para a cozinha e o corredor.');
const cozinha = new Sala('Cozinha', 'Uma cozinha velha com muitos utensílios. Há um pote de açúcar e um martelo.');
const corredor = new Sala('Corredor', 'O corredor é escuro. Uma lanterna e uma chave estão aqui.');
const salaTesouro = new Sala('Sala do Tesouro', 'Você encontrou a sala do tesouro! Um baú trancado está aqui.');

salaEntrada.adicionarPassagem(cozinha);
salaEntrada.adicionarPassagem(corredor);

cozinha.adicionarPassagem(salaEntrada);
cozinha.adicionarPassagem(salaTesouro);

corredor.adicionarPassagem(salaEntrada);
corredor.adicionarPassagem(salaTesouro);

// Criando objetos
const poteDeAcucar = new Objeto('Pote de Açúcar', 'Um pote de açúcar que parece estar trancado.', true);
const baú = new Objeto('Baú', 'Um baú trancado com um segredo dentro.', false);

// Criando ferramentas
const martelo = new Ferramenta('Martelo', 'Um martelo pesado, usado para quebrar coisas.', 3);
const chave = new Ferramenta('Chave', 'Uma chave antiga, talvez abra algum baú.', 1);
const lanterna = new Ferramenta('Lanterna', 'Uma lanterna para iluminar os ambientes escuros.', 5);

// Adicionando objetos e ferramentas nas salas
cozinha.adicionarObjeto(poteDeAcucar);
cozinha.adicionarObjeto(martelo);
corredor.adicionarObjeto(chave);
corredor.adicionarObjeto(lanterna);
salaTesouro.adicionarObjeto(baú);

// Criando o jogador
const jogador = new Jogador('Explorador');

// Começando o jogo
jogador.entrarNaSala(salaEntrada);



/*
instruçoes:
para percorer as salas utilize:
jogador.sairDaSala(nome-da-sala)

para pegar um objeto utileze:
jogador.pegarObjeto(nome-do-objeto)

para esvaziar a mochila utilize:
jogador.esvaziarMochila()

para utilizar ferramentas utileze:
jogador.usarFerramenta(nome-da-ferramenta)
*/